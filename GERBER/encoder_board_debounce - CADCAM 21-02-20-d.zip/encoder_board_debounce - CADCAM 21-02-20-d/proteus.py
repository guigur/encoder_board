import os,sys

# Get folder
if len(sys.argv) > 1:
    folder = sys.argv[1]
else:
    # folder = os.path.dirname(os.path.realpath(__file__))
    folder = os.getcwd()

convert =  {
        "Top Copper" : ".GTL",
        "Top Silk Screen" : ".GTO",
        "Top Solder Resist" : ".GTS",
        "Bottom Copper" : ".GBL",
        "Bottom Silk Screen" : ".GBO",
        "Bottom Solder Resist" : ".GBS",
        "Mechanical 1" : ".GML",
        "Drill" : ".TXT",
}

# Run through files in current folder
for filename in os.listdir(folder):
    # print "Looking at: " + filename
    infilename = os.path.join(folder,filename)
    if not os.path.isfile(infilename): continue
    oldbase = os.path.splitext(filename)
    for x in convert:
        if (x in filename) and (convert[x] not in filename):
            print "Convert " + filename + " to " + convert[x]
            if x == "Drill":
                newname = infilename.replace('.DRL', convert[x])
            else:
                newname = infilename.replace('.GBR', convert[x])
            output = os.rename(infilename, newname)